package com.example.agriwise.data.model

data class LoginBody (val email:String,val password:String)